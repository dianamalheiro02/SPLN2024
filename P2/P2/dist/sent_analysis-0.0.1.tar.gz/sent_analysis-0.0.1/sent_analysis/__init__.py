 #!/usr/bin/env python3  

'''
NAME

SYNOPSIS

DESCRIPTION
   
FILES

'''

from jjcli import * 
import re
import sys

__version__="0.0.1"

###
# Get a list filled with the words present in the input text
###
def tokeniza(texto):
    palavras = re.findall(r'[a-zA-Z]+(?:\-[a-zA-Z]+)?', texto.lower())
    return palavras

###
# Loading up the emojis and their description into a dictionary
###
def load_emoji_dict(file_path):
    emoji_dict = {}
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            emoji, description = line.strip().split('\t')  # Assuming emojis and descriptions are tab-separated
            emoji_dict[emoji] = description
    return emoji_dict

###
# Replacing the emoji with their description for a better analysis
###
def replace_emojis(text, emoji_dict):
    replaced_text = ""
    for char in text:
        if char in emoji_dict:
            replaced_text += emoji_dict[char]
        else:
            replaced_text += char
    return replaced_text

###
# Loading up the booster words into a dictionary
###
def load_sentiment_dict(file_path):
    sentiment_dict = {}
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            word, sentiment = line.strip().split('\t')
            print(word)
            if sentiment== "DECR":
                sentiment_dict[word] = -0.293   # According to LeIA's analysis
            else:
                sentiment_dict[word] = 0.293    # According to LeIA's analysis
    return sentiment_dict

###
# Loading up the words and their assigned sentiment from a given file
###
def load_sentiment_scores(file_path):
    sentiment_scores_dict = {}
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            columns = line.strip().split('\t')
            word = columns[0]
            score = float(columns[1])
            sentiment_scores_dict[word] = score
    return sentiment_scores_dict

###
# Used to analyse the polarity of a given text using the dictionaries made
###
def analysis(lista):   
    sentiment=0
    
    booster_dict_file = "data/booster.txt"    # Path to the file containing the booster words
    booster_dict = load_sentiment_dict(booster_dict_file)
    
    sentiment_scores_file = "lex.txt"  # Path to the file containing sentiment scores
    sentiment_scores_dict = load_sentiment_scores(sentiment_scores_file)
    
    negate_dict_file = "data/negate.txt"    # Path to the file containing negations in portuguese
    negate_dict = {}
    with open(negate_dict_file, 'r', encoding='utf-8') as file:
        for line in file:
            word = line.strip()
            negate_dict[word] = -0.74   # According to LeIA's analysis
            
    for palavra in lista:
        sentiment += booster_dict[palavra] +  sentiment_scores_dict[palavra] + negate_dict[palavra]
        
    return sentiment

###
# Main
###
def main():
    file_path = sys.argv[1] # File that we are analysing
    with open(file_path, "r", encoding="utf-8") as file:
        text = file.read()
    
    emoji_dict_file = "data/emoji.txt"    # Path to the file containing emoji descriptions
    emoji_dict = load_emoji_dict(emoji_dict_file)
    
    replaced_text = replace_emojis(text, emoji_dict)

    lista_palavras = tokeniza(replaced_text)

    sentiment = analysis(lista_palavras)
        
    print(f"This input text was: {sentiment}")
